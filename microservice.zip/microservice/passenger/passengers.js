const express= require('express');
const app=express();
const mongoose = require('mongoose');

const bodyParser= require('body-parser');
require('./Passenger');
const Passenger=mongoose.model('Passenger');
app.use(bodyParser.json());
// connect to our database
mongoose.connect('mongodb+srv://admin:admin@cluster0.d36b8.mongodb.net/Passenger2?retryWrites=true&w=majority',{ useNewUrlParser: true, useUnifiedTopology: true,useCreateIndex:true }); 


app.get('/',(req,res)=>
{
  console.log(req);
    res.send("This is passenger service"); 
})

app.get('/passengers',(req,res)=>
{
  Passenger.find().then((books)=>{
    res.json(books); 
  });
})

app.get('/passengers/:id', function(req, res) {
	
  Passenger.findById(req.params.id).then((passenger) =>
  {
    if(passenger)
    {
      res.json(passenger)
    }
    else{
      res.json("Invalid passenger id")
    }
  })
});
app.post('/passenger',(req,res)=>
{
  var newPassenger=req.body;
 
  var passenger=new Passenger(newPassenger);

  passenger.save().then(()=>{
    res.send("testing passenger route"); 
  });
   
});
app.listen(4500,()=>{
  console.log("passenger service up and working");
});