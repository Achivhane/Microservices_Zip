const express= require('express');
const app=express();
const mongoose = require('mongoose');
const bodyParser= require('body-parser');
const axios = require("axios")

mongoose.connect('mongodb+srv://admin:admin@cluster0.d36b8.mongodb.net/booking2?retryWrites=true&w=majority',{ useNewUrlParser: true, useUnifiedTopology: true,useCreateIndex:true }); 


require('./Booking');
const Booking=mongoose.model('Booking');
app.use(bodyParser.json());

app.get('/',(req,res)=>
{
  console.log(req);
    res.send("This is booking service"); 
})

app.post('/books',(req,res)=>
{

  var newBooks={
    trainID:mongoose.Types.ObjectId(req.body.trainID),
    passengerID:mongoose.Types.ObjectId(req.body.passengerID),
      bookedDate:req.body.bookedDate,
      paymentDone:req.body.paymentDone
  }
 
  var books=new Booking(newBooks);
  console.log(books);
  books.save().then(()=>{
    res.send("ticket book"); 
    console.log("ticket booked");
  });
   
}); 

 app.get('/booking/:id',  function(req, res) {
	console.log("id is :"+req.params.id)
    Booking.findById(req.params.id).then((booking) =>
    {
        console.log(booking)
       
       if(booking)
       {
axios.all([
  axios.get('http://localhost:4500/passengers/'+booking.passengerID),
  axios.get('http://localhost:4502/train/'+booking.trainID)
])
.then(response => {
  //this will be executed only when all requests are complete
  console.log('Date created: ', response[0].data);
  console.log('Date created: ', response[1].data.trainName);

  var passengerObject ={name : response[0].data.name , email : response[0].data.email , trainName : response[1].data.train_name,from : response[1].data.from, to : response[1].data.to}
  res.send(passengerObject);
});
       
       }
       else{
           res.send("invalid Booking")
       }
    })
});
app.get('/books',(req,res)=>
{
    Booking.find().then((books)=>{
    res.json(books); 
  });
})
app.listen(4501,()=>{
    console.log("passenger service up and working");
  });