const express= require('express');
const app=express();
const mongoose = require('mongoose');
const bodyParser= require('body-parser');


mongoose.connect('mongodb+srv://admin:admin@cluster0.d36b8.mongodb.net/trains2?retryWrites=true&w=majority',{ useNewUrlParser: true, useUnifiedTopology: true,useCreateIndex:true }); 

require('./Train');
const Train=mongoose.model('Train');

app.use(bodyParser.json());

app.get('/',(req,res)=>
{
  
    res.send("This is admin service"); 
})

app.post('/trains',(req,res)=>
{
  var newTrain=req.body;
 
  var trains=new Train(newTrain);

  trains.save().then(()=>{
    res.send("train added"); 
  });
   
});
app.get('/train/:id', function(req, res) {
	
    Train.findById(req.params.id).then((trains) =>
    {
      res.send(trains);
    })
  });

app.get('/getAllTrains',(req,res)=>
{
    Train.find().then((trains)=>{
    res.json(trains); 
  });
})
app.listen(4502,()=>{
    console.log("passenger service up and working");
  });